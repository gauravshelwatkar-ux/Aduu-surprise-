ADUU SURPRISE PAGE 💗

1. Keep index.html as the main page file.
2. To make a QR code that works for Aditi on any phone, this page must first be published at a public HTTPS website address.
3. Upload index.html to a static hosting service (for example, GitHub Pages or Netlify).
4. Once you have the public page URL, create a QR code that points to that exact URL.
5. Test the URL and QR code on another phone before sharing.

The page is mobile-friendly and includes four screens, Marathi-English friendship compliments, floating hearts, sparkles and a replay button.
